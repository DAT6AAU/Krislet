public enum ActionType {
    TURN_LEFT, TURN_RIGHT, MOVE_FORWARD, NOTHING;

    public double amount;
}
