package objects;

public class BallInfo extends ObjectInfo {
    public BallInfo() {
        super (ObjectType.BALL);
    }
}
